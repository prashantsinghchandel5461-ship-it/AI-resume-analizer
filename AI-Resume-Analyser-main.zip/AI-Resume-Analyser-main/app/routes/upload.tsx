import { type FormEvent, useRef, useState } from 'react';
import Navbar from "~/components/NavBar";
import FileUploader from "~/components/FileUploader";
import { usePuterStore } from "~/lib/puter";
import { useNavigate } from "react-router";
import { convertPdfToImage } from "~/lib/pdf2img";
import { generateUUID } from "~/lib/utils";
import { prepareInstructions } from "../../constants";

const wait=(ms:number)=>new Promise(r=>setTimeout(r,ms));

/* IMPROVEMENT 1:
Retry wrapper for transient failures (uploads, AI calls, KV writes)
*/
async function withRetry<T>(fn:()=>Promise<T>, retries=3){
 let err;
 for(let i=0;i<retries;i++){
   try{return await fn();}
   catch(e){err=e; if(i<retries-1) await wait(500*Math.pow(2,i));}
 }
 throw err;
}

/* IMPROVEMENT 2:
Simple cache key for avoiding duplicate analysis requests
*/
const makeCacheKey=(file:File,jobTitle:string,jobDescription:string)=>
 `analysis:${file.name}:${file.size}:${jobTitle}:${jobDescription.slice(0,120)}`;

const Upload = () => {
 const { fs, ai, kv } = usePuterStore();
 const navigate = useNavigate();
 const [isProcessing,setIsProcessing]=useState(false);
 const [statusText,setStatusText]=useState('');
 const [file,setFile]=useState<File|null>(null);

 /* IMPROVEMENT 3:
 In-flight lock prevents duplicate submissions/double-clicks
 */
 const inFlightRef=useRef(false);

 const handleFileSelect=(file:File|null)=>setFile(file);

 const handleAnalyze=async({companyName,jobTitle,jobDescription,file}:{companyName:string,jobTitle:string,jobDescription:string,file:File})=>{
 if(inFlightRef.current) return;
 inFlightRef.current=true;
 setIsProcessing(true);

 let uploadedFile:any=null;
 let uploadedImage:any=null;

 try{

 /* IMPROVEMENT 4:
 Cache check avoids rerunning identical analysis
 */
 const cacheKey=makeCacheKey(file,jobTitle,jobDescription);
 const cached=await kv.get(cacheKey);
 if(cached){
   const parsed=JSON.parse(cached as string);
   navigate(`/resume/${parsed.id}`);
   return;
 }

 /* IMPROVEMENT 5:
 Parallelize PDF upload + PDF->image conversion
 Reduces end-to-end latency significantly
 */
 setStatusText('Uploading and converting...');
 const [pdfUpload,imageFile]=await Promise.all([
   withRetry(()=>fs.upload([file])),
   convertPdfToImage(file)
 ]);

 uploadedFile=pdfUpload;

 if(!uploadedFile) throw new Error('PDF upload failed');
 if(!imageFile.file) throw new Error('PDF conversion failed');

 /* IMPROVEMENT 6:
 Retry-safe image upload
 */
 setStatusText('Uploading rendered image...');
 uploadedImage=await withRetry(()=>fs.upload([imageFile.file as File]));
 if(!uploadedImage) throw new Error('Image upload failed');

 const uuid=generateUUID();
 const data={
  id:uuid,
  resumePath:uploadedFile.path,
  imagePath:uploadedImage.path,
  companyName,
  jobTitle,
  jobDescription,
  feedback:''
 };

 /* IMPROVEMENT 7:
 Retry-safe KV persistence
 */
 await withRetry(()=>kv.set(`resume:${uuid}`,JSON.stringify(data)) as any);

 setStatusText('Running AI analysis...');

 /* IMPROVEMENT 8:
 Retry-safe AI inference request
 */
 const feedback = await withRetry<AIResponse | undefined>(() =>
   ai.feedback(
      uploadedFile.path,
      prepareInstructions({
        jobTitle,
        jobDescription
      })
   )
);

 if(!feedback) throw new Error('AI analysis failed');

 const feedbackText=
 typeof feedback.message.content==='string'
 ? feedback.message.content
 : feedback.message.content[0].text;

 /* IMPROVEMENT 9:
 Safe JSON parsing for unpredictable model output
 */
 let parsedFeedback;
 try{
   parsedFeedback=JSON.parse(feedbackText);
 }catch{
   throw new Error('Invalid AI JSON response');
 }

 data.feedback=parsedFeedback;

 await withRetry(()=>kv.set(`resume:${uuid}`,JSON.stringify(data)) as any);

 /* IMPROVEMENT 10:
 Cache completed analysis result for reuse
 */
 await kv.set(cacheKey,JSON.stringify({id:uuid}));

 navigate(`/resume/${uuid}`);
 }
 catch(err){
  setStatusText(
   err instanceof Error ? err.message : 'Processing failed'
  );

 /* IMPROVEMENT 11:
 Rollback cleanup if pipeline partially fails
 */
  try{
   if(uploadedImage?.path) await fs.delete(uploadedImage.path);
   if(uploadedFile?.path) await fs.delete(uploadedFile.path);
  }catch{}
 }
 finally{
  inFlightRef.current=false;
  setIsProcessing(false);
 }
 }

 const handleSubmit=(e:FormEvent<HTMLFormElement>)=>{
 e.preventDefault();
 if(!file || isProcessing) return;
 const form=e.currentTarget;
 const formData=new FormData(form);

 handleAnalyze({
  companyName:formData.get('company-name') as string,
  jobTitle:formData.get('job-title') as string,
  jobDescription:formData.get('job-description') as string,
  file
 });
 }

 return (
 <main className="bg-[url('/images/bg-main.svg')] bg-cover">
 <Navbar/>
 <section className="main-section">
 <div className="page-heading py-16">
 <h1>Smart feedback for your dream job</h1>
 {isProcessing ? (
 <>
 <h2>{statusText}</h2>
 <img src="/images/resume-scan.gif" className="w-full" />
 </>
 ):(
 <h2>Drop your resume for an ATS score and improvement tips</h2>
 )}
 {!isProcessing && (
 <form onSubmit={handleSubmit} className="flex flex-col gap-4 mt-8">
 <div className="form-div">
 <label htmlFor="company-name">Company Name</label>
 <input name="company-name" id="company-name" />
 </div>
 <div className="form-div">
 <label htmlFor="job-title">Job Title</label>
 <input name="job-title" id="job-title" />
 </div>
 <div className="form-div">
 <label htmlFor="job-description">Job Description</label>
 <textarea rows={5} name="job-description" id="job-description" />
 </div>
 <div className="form-div">
 <label htmlFor="uploader">Upload Resume</label>
 <FileUploader onFileSelect={handleFileSelect}/>
 </div>

 {/* IMPROVEMENT 12:
 Disable button during processing to prevent duplicate submits
 */}
 <button disabled={isProcessing} className="primary-button" type="submit">
 Analyze Resume
 </button>
 </form>
 )}
 </div>
 </section>
 </main>
 )
}

export default Upload;


