/* pdfToImage.ts */

import type * as PDFJS from "pdfjs-dist";

export interface PdfConversionResult {
  imageUrl: string;
  file: File | null;
  error?: string;
}

let pdfjsLib: typeof PDFJS | null = null;
let loadingPromise: Promise<typeof PDFJS> | null = null;

/**
 * Load PDF.js once (browser-only)
 */
async function loadPdfJs(): Promise<typeof PDFJS> {
  if (pdfjsLib) return pdfjsLib;

  if (typeof window === "undefined") {
    throw new Error("PDF.js can only be loaded in browser");
  }

  if (!loadingPromise) {
    loadingPromise = (async () => {
      const pdfjs = await import("pdfjs-dist");
      const worker = await import(
        "pdfjs-dist/build/pdf.worker.mjs?url"
      );

      pdfjs.GlobalWorkerOptions.workerSrc = worker.default;

      pdfjsLib = pdfjs;
      return pdfjs;
    })();
  }

  return loadingPromise;
}

/**
 * Convert selected PDF page into PNG
 */
export async function convertPdfToImage(
  file: File,
  scale: number = 3,
  pageNumber: number = 1
): Promise<PdfConversionResult> {

  try {
    /* IMPROVEMENT 1: Validate input */
    if (file.type !== "application/pdf") {
      throw new Error("Invalid file type. Must be a PDF.");
    }

    const pdfjs = await loadPdfJs();

    const buffer = await file.arrayBuffer();

    const pdf = await pdfjs.getDocument({
      data: buffer
    }).promise;

    /* IMPROVEMENT 2: Prevent invalid page requests */
    if (pageNumber > pdf.numPages) {
      throw new Error(
        `PDF only has ${pdf.numPages} pages`
      );
    }

    const page = await pdf.getPage(pageNumber);

    const viewport = page.getViewport({
      scale
    });

    const canvas = document.createElement("canvas");

    const context = canvas.getContext("2d");

    if (!context) {
      throw new Error(
        "Failed to get canvas context"
      );
    }

    canvas.width = viewport.width;
    canvas.height = viewport.height;

    /* IMPROVEMENT 3: Use correct PDF.js render API */
   await page.render({
  canvas,
  canvasContext: context,
  viewport
}).promise;
    return new Promise((resolve) => {

      canvas.toBlob(
        (blob) => {

          if (!blob) {
            resolve({
              imageUrl: "",
              file: null,
              error: "Failed to create blob"
            });
            return;
          }

          const imageFile = new File(
            [blob],
            file.name.replace(
              /\.pdf$/i,
              `.page-${pageNumber}.png`
            ),
            {
              type: "image/png"
            }
          );

          const imageUrl =
            URL.createObjectURL(blob);

          /* IMPROVEMENT 4:
             Clean canvas memory */
          canvas.width = 0;
          canvas.height = 0;

          resolve({
            imageUrl,
            file: imageFile
          });

        },
        "image/png",
        1
      );

    });

  } catch (err) {

    return {
      imageUrl: "",
      file: null,
      error:
        err instanceof Error
          ? err.message
          : String(err)
    };

  }
}